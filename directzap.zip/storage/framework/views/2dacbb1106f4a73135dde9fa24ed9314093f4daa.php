<script>
  setTimeout(() => {
    location.href = '<?php echo e($link); ?>';
  }, 100);
</script>
<?php /**PATH /home/lorenzo/Projects/site-brunovg-refactor-2/resources/views/redirect.blade.php ENDPATH**/ ?>