<script>
  setTimeout(() => {
    location.href = '{{ $link }}';
  }, 100);
</script>
